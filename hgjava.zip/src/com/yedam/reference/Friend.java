package com.yedam.reference;

// 친구: 이름(문자열 ), 몸무게(실수), 점수(정수) 
public class Friend {
	public String name; //필드 생성
	public double weight; //필드 생성
	public int score; //필드 생성
































}
