package com.yedam.variable;

// 복합구조의 데이터.
public class Member { // Member 안의 데이터 타입
	// const obj = {name: "홍길동", age:20, height:180.5}
	String name;
	int age;
	double height;
}
