package com.yedam.impl;

public interface Flyer {

	void takeOFF(); // 이륙.

	void fly(); // 비행.

	void land(); // 착륙.

}
