package com.yedam.impl;

public class Seaplane extends Airplane {
	
}
