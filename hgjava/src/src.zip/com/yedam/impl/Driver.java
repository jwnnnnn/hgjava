package com.yedam.impl;

public class Driver {
	void drive(Flyer flyer) {
		flyer.fly();
	}
}
