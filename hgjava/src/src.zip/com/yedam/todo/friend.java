package com.yedam.todo;

public class friend {
	String name; //필드 생성
	double weight; //필드 생성
	int score; //필드 생성
}
