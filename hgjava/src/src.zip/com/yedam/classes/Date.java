package com.yedam.classes;

public class Date {

	public int getYear() {
		// TODO Auto-generated method stub
		return 0;
	}

}
